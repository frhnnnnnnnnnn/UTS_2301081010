import 'package:flutter/material.dart';
import 'peminjaman.dart';
import 'result_screen.dart';

class LoanFormScreen extends StatefulWidget {
  @override
  _LoanFormScreenState createState() => _LoanFormScreenState();
}

class _LoanFormScreenState extends State<LoanFormScreen> {
  final _formKey = GlobalKey<FormState>();

  final TextEditingController _kodeController = TextEditingController();
  final TextEditingController _namaController = TextEditingController();
  final TextEditingController _kodeNasabahController = TextEditingController();
  final TextEditingController _namaNasabahController = TextEditingController();
  final TextEditingController _jumlahPinjamanController = TextEditingController();
  final TextEditingController _lamaPinjamanController = TextEditingController();

  double _bunga = 12.0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Form Peminjaman'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              TextFormField(
                controller: _kodeController,
                decoration: InputDecoration(labelText: 'Kode Peminjaman'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter Kode Peminjaman';
                  }
                  return null;
                },
              ),
              TextFormField(
                controller: _namaController,
                decoration: InputDecoration(labelText: 'Nama Admin'),
              ),
              TextFormField(
                controller: _kodeNasabahController,
                decoration: InputDecoration(labelText: 'Kode Nasabah'),
              ),
              TextFormField(
                controller: _namaNasabahController,
                decoration: InputDecoration(labelText: 'Nama Nasabah'),
              ),
              TextFormField(
                controller: _jumlahPinjamanController,
                decoration: InputDecoration(labelText: 'Jumlah Pinjaman'),
                keyboardType: TextInputType.number,
              ),
              TextFormField(
                controller: _lamaPinjamanController,
                decoration: InputDecoration(labelText: 'Lama Pinjaman (bulan)'),
                keyboardType: TextInputType.number,
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    Peminjaman peminjaman = Peminjaman(
                      kode: _kodeController.text,
                      nama: _namaController.text,
                      kodePeminjaman: _kodeController.text,
                      tanggal: DateTime.now(),
                      kodeNasabah: _kodeNasabahController.text,
                      namaNasabah: _namaNasabahController.text,
                      jumlahPinjaman: double.parse(_jumlahPinjamanController.text),
                      lamaPinjaman: int.parse(_lamaPinjamanController.text),
                      bunga: _bunga,
                    );

                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => ResultScreen(peminjaman: peminjaman),
                      ),
                    );
                  }
                },
                child: Text('Submit'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
