import 'package:flutter/material.dart';
import 'peminjaman.dart';

class ResultScreen extends StatelessWidget {
  final Peminjaman peminjaman;

  ResultScreen({required this.peminjaman});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Hasil Pinjaman'),
        backgroundColor: Colors.blueAccent,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Card(
          elevation: 8,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15),
          ),
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Detail Pinjaman',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Colors.blueAccent,
                  ),
                ),
                SizedBox(height: 10),
                Divider(color: Colors.grey),
                SizedBox(height: 10),
                _buildResultRow('Kode Peminjaman', peminjaman.kodePeminjaman),
                _buildResultRow('Nama Nasabah', peminjaman.namaNasabah),
                _buildResultRow('Jumlah Pinjaman', peminjaman.jumlahPinjaman.toStringAsFixed(2)),
                _buildResultRow('Lama Pinjaman', '${peminjaman.lamaPinjaman} bulan'),
                _buildResultRow('Bunga per Bulan', peminjaman.bungaPerBulan.toStringAsFixed(2)),
                _buildResultRow('Angsuran Pokok', peminjaman.angsuranPokok.toStringAsFixed(2)),
                _buildResultRow('Angsuran per Bulan', peminjaman.angsuranPerBulan.toStringAsFixed(2)),
                _buildResultRow('Total Hutang', peminjaman.totalHutang.toStringAsFixed(2)),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildResultRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w600,
              color: Colors.black87,
            ),
          ),
          Text(
            value,
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w400,
              color: Colors.black54,
            ),
          ),
        ],
      ),
    );
  }
}
