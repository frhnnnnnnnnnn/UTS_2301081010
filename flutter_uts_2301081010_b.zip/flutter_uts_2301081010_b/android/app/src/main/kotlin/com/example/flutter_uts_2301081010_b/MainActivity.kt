package com.example.flutter_uts_2301081010_b

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
